#!/bin/sh

###############################################################################
# ubuntu-fix-wifi
# Standalone script to fix failing QCA6174 in Ubuntu
#
# Copyright (C) 2022 Protectli
# 
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Version: 0.3.1
# Author: Ed Borgquist IV <ed.borgquist@protectli.com>
###############################################################################

set -e ;

error_handler() {
	[ $? -eq 0 ] && exit ;
	if [ -z "$LOADED_MODULES" ] ; then
		# shellcheck disable=SC2086
		modprobe -qa $LOADED_MODULES ;
	fi
}
trap error_handler EXIT ;

pre_fail() {
	echo "This script has stopped prematurely and no action has been taken." ;
	exit 1 ;
}

show_help() {
	echo "Usage: ./$0 [OPTION]..."
	echo "Restores an older version of firmware for the Atheros QCA6174 WiFi module." ;
	echo "Options:" ;
	echo "  -h  Displays this [h]elp text." ;
	echo "  -r  [r]everses installation from backup." ;
	echo "  -f  Dangerous! [f]orces installation even if checksums don't match," ;
	echo "      or if firmware versions still seem OK, or if the host OS is not Ubuntu." ;
	echo "  -v  [v]erbose mode. Shows all commands as they run." ;
	exit 0 ;
}

invalid_option() {
	echo "Invalid parameter passed." ;
	show_help ;
	exit 1 ;
}

while getopts :fhrv opt ; do
	case $opt in
		f)
			FORCE=1
			;;
		h)
			show_help
			;;
		r)
			REVERSE_MODE=1
			;;
		v)
			# VERBOSE=1
			set -x
			;;
		\?)
			invalid_option
			;;
	esac
done

if [ "$(id -u)" -ne "0" ] ; then
	echo "This script must be run with root privileges.";
	pre_fail ;
fi

FIRMWARE="board-2.bin" ;
BOARD="firmware-6.bin" ;
FIRMWARE_PATH="/lib/firmware/ath10k/QCA6174/hw3.0" ;

BASEDIR=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd) ;
cd "$BASEDIR" ;

# Check if we're running Ubuntu
if ! lsb_release -d | grep -q Ubuntu ; then
	echo "This tool is meant for Ubuntu only." ;
	echo "If you really want to proceed, pass the -f parameter to force installation." ;
	pre_fail ;
fi

# Check if firmware binary was decompressed.
if ! [ -f "vendor/$FIRMWARE" ] ; then
	echo "Firmware not found. Redownload this tool, extract it, and try again." ;
	pre_fail ;
fi

# Check if firmware board data was decompressed.
if ! [ -f "vendor/$BOARD" ] ; then
	echo "Board data not found. Redownload this tool, extract it, and try again." ;
	pre_fail ;
fi

# Check if system has prerequisite md5sum installed.
if ! command -v md5sum > /dev/null && ! "$FORCE" ; then
	echo "No way to verify md5sum of downloaded files." ;
	echo "Install the md5sum tool or pass -f to force installation." ;
	pre_fail ;
fi

# Check MD5 checksum.
cd vendor/ ;
if ! md5sum -c --status checksums && ! "$FORCE" ; then
	echo "Firmware and/or board data MD5 checksum does not match!" ;
	echo "Redownload this tool, extract it, and try again." ;
	pre_fail ;
fi
cd "$BASEDIR" ;

# Check if there "correct" firmware is already installed.
cd "$FIRMWARE_PATH" ;
if md5sum -c --status "$BASEDIR/vendor/checksums" ; then
	echo "Seems you already have the replacement firmware and board data." ;
	echo "Nothing to do here." ;
	pre_fail ;
fi
cd "$BASEDIR" ;

if [ 1 = "$REVERSE_MODE" ] ; then
	echo "Restoring default wifi firmware from backup." ;
else
	echo "Replacing default wifi firmware with corrected versions." ;
fi

# Pin (or un-pin) apt package to prevent/allow updates
if [ 1 = "$REVERSE_MODE" ] ; then
	apt-mark unhold linux-firmware > /dev/null ;
else
	apt-mark hold linux-firmware > /dev/null ;
fi

# Find modules that must be unloaded for this operation
LOADED_MODULES=$(lsmod | grep ath10k | awk '{print $1}' | tr "\n" " ") ;

# shellcheck disable=SC2086
modprobe -qra $LOADED_MODULES ;
mkdir -p "$FIRMWARE_PATH/backups" ;

if [ 1 = "$REVERSE_MODE" ] ; then
	if ! [ -f "$FIRMWARE_PATH/backups/$FIRMWARE" ] || ! [ -f "$FIRMWARE_PATH/backups/$BOARD" ] ; then
		echo "No backups found, so cannot restore from backup." ;
		pre_fail ;
	fi
	cp -f "$FIRMWARE_PATH/backups/$FIRMWARE" "$FIRMWARE_PATH" ;
	cp -f "$FIRMWARE_PATH/backups/$BOARD" "$FIRMWARE_PATH" ;
else
	cp -f "$FIRMWARE_PATH/$FIRMWARE" "$FIRMWARE_PATH/backups" ;
	cp -f "$FIRMWARE_PATH/$BOARD" "$FIRMWARE_PATH/backups" ;
	cp -f vendor/$FIRMWARE "$FIRMWARE_PATH" ;
	cp -f vendor/$BOARD "$FIRMWARE_PATH" ;
fi

# shellcheck disable=SC2086
modprobe -qa $LOADED_MODULES ;

echo "Done." ;
exit 0 ;
